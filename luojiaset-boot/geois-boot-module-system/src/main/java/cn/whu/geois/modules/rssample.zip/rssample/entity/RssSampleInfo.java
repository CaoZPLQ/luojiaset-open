package cn.whu.geois.modules.rssample.entity;

/**
 * @author czp
 * @version 1.0
 * @date 2021/6/6 22:10
 */
public class RssSampleInfo {
}
