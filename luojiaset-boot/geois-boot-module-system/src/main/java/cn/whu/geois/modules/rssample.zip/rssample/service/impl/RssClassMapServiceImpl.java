package cn.whu.geois.modules.rssample.service.impl;

import cn.whu.geois.modules.rssample.entity.RssClassMap;
import cn.whu.geois.modules.rssample.mapper.RssClassMapMapper;
import cn.whu.geois.modules.rssample.service.IRssClassMapService;
import com.baomidou.dynamic.datasource.annotation.DS;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: 数据集类别关系映射表
 * @Author: jeecg-boot
 * @Date:   2021-05-10
 * @Version: V1.0
 */
@Service
@DS("postgres")
public class RssClassMapServiceImpl extends ServiceImpl<RssClassMapMapper, RssClassMap> implements IRssClassMapService {

}
