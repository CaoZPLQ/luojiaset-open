package cn.whu.geois.modules.rssample.entity.ogc;

import lombok.Data;

/**
 * @author czp
 * @version 1.0
 * @date 2021/8/7 21:17
 */
@Data
public class AITrainingDataClassMap {
    private Integer datasetId;
    private String classes;
}
