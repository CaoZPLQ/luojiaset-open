package cn.whu.geois.modules.rssample.service.impl;

import cn.whu.geois.modules.rssample.entity.RssCdSampleClass;
import cn.whu.geois.modules.rssample.mapper.RssCdSampleClassMapper;
import cn.whu.geois.modules.rssample.service.IRssCdSampleClassService;
import com.baomidou.dynamic.datasource.annotation.DS;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: 样本_变化要素类别关联表
 * @Author: jeecg-boot
 * @Date:   2021-01-29
 * @Version: V1.0
 */
@Service
@DS("postgres")
public class RssCdSampleClassServiceImpl extends ServiceImpl<RssCdSampleClassMapper, RssCdSampleClass> implements IRssCdSampleClassService {

}
