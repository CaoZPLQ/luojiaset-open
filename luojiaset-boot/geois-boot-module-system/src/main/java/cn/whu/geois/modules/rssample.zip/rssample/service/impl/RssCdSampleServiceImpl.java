package cn.whu.geois.modules.rssample.service.impl;

import cn.whu.geois.modules.rssample.entity.RssCdSample;
import cn.whu.geois.modules.rssample.mapper.RssCdSampleMapper;
import cn.whu.geois.modules.rssample.service.IRssCdSampleService;
import org.springframework.stereotype.Service;

import com.baomidou.mybatisplus.extension.service.impl.ServiceImpl;

/**
 * @Description: 变化检测样本元数据表
 * @Author: jeecg-boot
 * @Date:   2021-08-12
 * @Version: V1.0
 */
@Service
public class RssCdSampleServiceImpl extends ServiceImpl<RssCdSampleMapper, RssCdSample> implements IRssCdSampleService {

}
