package cn.whu.geois.modules.rssample.analysis;

import lombok.Data;

/**
 * @author czp
 * @version 1.0
 * @date 2021/3/29 11:26
 */
@Data
public class RssParam {
    private String objectName;
}
