<template>
  <a-drawer
      :title="title"
      :width="800"
      placement="right"
      :closable="false"
      @close="close"
      :visible="visible"
  >

    <a-spin :spinning="confirmLoading">
      <a-form :form="form">
      
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="datasetId">
          <a-input placeholder="请输入datasetId" v-decorator="['datasetId', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="sampleArea">
          <a-input placeholder="请输入sampleArea" v-decorator="['sampleArea', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="sampleQuality">
          <a-input placeholder="请输入sampleQuality" v-decorator="['sampleQuality', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="sampleLabeler">
          <a-input placeholder="请输入sampleLabeler" v-decorator="['sampleLabeler', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="annotationDate">
          <a-input placeholder="请输入annotationDate" v-decorator="['annotationDate', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preSampleDate">
          <a-input placeholder="请输入preSampleDate" v-decorator="['preSampleDate', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postSampleDate">
          <a-input placeholder="请输入postSampleDate" v-decorator="['postSampleDate', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preImagePath">
          <a-input placeholder="请输入preImagePath" v-decorator="['preImagePath', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postImagePath">
          <a-input placeholder="请输入postImagePath" v-decorator="['postImagePath', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preImageType">
          <a-input placeholder="请输入preImageType" v-decorator="['preImageType', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preImageChannels">
          <a-input placeholder="请输入preImageChannels" v-decorator="['preImageChannels', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preImageResolution">
          <a-input placeholder="请输入preImageResolution" v-decorator="['preImageResolution', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="labelPath">
          <a-input placeholder="请输入labelPath" v-decorator="['labelPath', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="preInstrument">
          <a-input placeholder="请输入preInstrument" v-decorator="['preInstrument', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="trnValueTest">
          <a-input placeholder="请输入trnValueTest" v-decorator="['trnValueTest', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="sampleWidth">
          <a-input placeholder="请输入sampleWidth" v-decorator="['sampleWidth', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="sampleHeight">
          <a-input placeholder="请输入sampleHeight" v-decorator="['sampleHeight', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postImageType">
          <a-input placeholder="请输入postImageType" v-decorator="['postImageType', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postImageChannels">
          <a-input placeholder="请输入postImageChannels" v-decorator="['postImageChannels', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postImageResolution">
          <a-input placeholder="请输入postImageResolution" v-decorator="['postImageResolution', {}]" />
        </a-form-item>
        <a-form-item
          :labelCol="labelCol"
          :wrapperCol="wrapperCol"
          label="postInstrument">
          <a-input placeholder="请输入postInstrument" v-decorator="['postInstrument', {}]" />
        </a-form-item>
		
      </a-form>
    </a-spin>
    <a-button type="primary" @click="handleOk">确定</a-button>
    <a-button type="primary" @click="handleCancel">取消</a-button>
  </a-drawer>
</template>

<script>
  import { httpAction } from '@/api/manage'
  import pick from 'lodash.pick'
  import moment from "moment"

  export default {
    name: "RssCdSampleModal",
    data () {
      return {
        title:"操作",
        visible: false,
        model: {},
        labelCol: {
          xs: { span: 24 },
          sm: { span: 5 },
        },
        wrapperCol: {
          xs: { span: 24 },
          sm: { span: 16 },
        },

        confirmLoading: false,
        form: this.$form.createForm(this),
        validatorRules:{
        },
        url: {
          add: "/rssample/rssCdSample/add",
          edit: "/rssample/rssCdSample/edit",
        },
      }
    },
    created () {
    },
    methods: {
      add () {
        this.edit({});
      },
      edit (record) {
        this.form.resetFields();
        this.model = Object.assign({}, record);
        this.visible = true;
        this.$nextTick(() => {
          this.form.setFieldsValue(pick(this.model,'datasetId','sampleArea','sampleQuality','sampleLabeler','annotationDate','preSampleDate','postSampleDate','preImagePath','postImagePath','preImageType','preImageChannels','preImageResolution','labelPath','preInstrument','trnValueTest','sampleWidth','sampleHeight','postImageType','postImageChannels','postImageResolution','postInstrument'))
		  //时间格式化
        });

      },
      close () {
        this.$emit('close');
        this.visible = false;
      },
      handleOk () {
        const that = this;
        // 触发表单验证
        this.form.validateFields((err, values) => {
          if (!err) {
            that.confirmLoading = true;
            let httpurl = '';
            let method = '';
            if(!this.model.id){
              httpurl+=this.url.add;
              method = 'post';
            }else{
              httpurl+=this.url.edit;
               method = 'put';
            }
            let formData = Object.assign(this.model, values);
            //时间格式化
            
            console.log(formData)
            httpAction(httpurl,formData,method).then((res)=>{
              if(res.success){
                that.$message.success(res.message);
                that.$emit('ok');
              }else{
                that.$message.warning(res.message);
              }
            }).finally(() => {
              that.confirmLoading = false;
              that.close();
            })



          }
        })
      },
      handleCancel () {
        this.close()
      },


    }
  }
</script>

<style lang="less" scoped>
/** Button按钮间距 */
  .ant-btn {
    margin-left: 30px;
    margin-bottom: 30px;
    float: right;
  }
</style>